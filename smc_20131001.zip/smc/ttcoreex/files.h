typedef struct {
   char group[BUFFER_SIZE];
   char  name[BUFFER_SIZE];
} sosItem;

sosItem soski[BUFFER_SIZE];

