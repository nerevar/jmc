// --CHANGED by Anton Likhtarov for resource support
namespace rs {
extern HINSTANCE hInst;
char* rs(int StrId);

}
// --END
